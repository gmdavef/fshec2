from setuptools import setup

setup(
    name='fshec2',
    version='1.0.0',
    description='My create_package description',
    packages=['fshec2'],
    package_data={'fshec2': ['*.pyc']},
    install_requires=[],
    author='Your Name',
    author_email='youremail@example.com',
    url='https://github.com/yourusername/yourproject',
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Libraries',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
    ],
)
